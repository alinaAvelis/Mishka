'use strict';

window.addEventListener('DOMContentLoaded', () => {

    /*...modal windows...*/
    const orderModalOpen = document.querySelectorAll("[data-modalOpen]"),
    orderModal = document.querySelector("[data-orderModal]"),
    orderModalClose = document.querySelector("[data-orderClose]"),
    autofocus = document.querySelector(".size-s");

    const reviewModal = document.querySelector("[data-reviewModal]"),
    form = reviewModal.querySelector('form'),
    reviewModalOpen = document.querySelector("[data-reviewOpen]"),
    reviewModalClose = document.querySelector("[data-reviewClose]");

    console.log(reviewModalOpen);

    function openModal(item, openClass) {
    item.classList.add(openClass);
    document.body.style.overflow = 'hidden';
    }

    function closeModal(item, openClass) {
    item.classList.remove(openClass);
    document.body.style.overflow = '';
    }

    // order modal

    orderModalOpen.forEach(btn => {
    btn.addEventListener("click", () => { 
    openModal(orderModal, 'modal-show');
    autofocus.focus();
    });

    });

    orderModalClose.addEventListener("click", (e) => { 
    if(e.target === orderModalClose) {
    closeModal(orderModal, 'modal-show'); 
    }
    });

    document.addEventListener('keydown', (e) => {
    if(e.code === "Escape" && orderModal.classList.contains('modal-show')) {
    closeModal(orderModal, 'modal-show'); 
    }
    });

    // review modal

    reviewModalOpen.addEventListener("click", () => { 
    openModal(reviewModal, 'modal-show');
    });

    reviewModalClose.addEventListener("click", (e) => { 
    if(e.target ===  reviewModalClose) {
    closeModal(reviewModal, 'modal-show'); 
    }
    });

    const message = {
    loading: 'assets/img/forms/spinner.svg',
    success: 'Спасибо, скоро мы с вами свяжемся',
    failure: 'Что-то пошло не так...'
    };

    bindPostData(form); 

    const postData = async (url, data) => {
    const res = await fetch(url, {
    method: "POST",
    headers: {
        'Content-type': 'application/json; charset=utf-8'
    },
    body: data
    });

    return await res.json();
    };

    function bindPostData(form) {
    form.addEventListener('submit', (e) => {
    e.preventDefault();

    const statusMessage = document.createElement('img');
    statusMessage.src = message.loading;
    statusMessage.style.cssText = `
        display: block;
        margin: 0 auto;
    `;
    form.insertAdjacentElement('afterend', statusMessage);

    const formData = new FormData(form);

    const json = JSON.stringify(Object.fromEntries(formData.entries()));

    postData('http://localhost:3000/requests', json)
    .then(data => {
        console.log(data);
        showThanksModal(message.success);
        statusMessage.remove(); /*удаляем блок с сообщениями со страницы*/
    }).catch(() => {
        showThanksModal(message.failure);
    }).finally(() => {
        form.reset(); /*сбрасываем форму после успешной отправки*/
    });

    });
    }  

    function showThanksModal(message) {
    const prevModalDialog = document.querySelector('.modal');

    prevModalDialog.classList.add('menu__hide');
    openModal();

    const thanksModal = document.createElement('div');
    thanksModal.classList.add('.modal');
    thanksModal.classList.add('.modal--height');
    thanksModal.innerHTML = `
    <div class="modal-background">
        <div class="modal__title">${message}</div> 
    </div>
    `;

    reviewModal.append(thanksModal);

    setTimeout(() => {
    thanksModal.remove();
    prevModalDialog.classList.add('modal-show');
    prevModalDialog.classList.remove('menu__hide');
    closeModal();
    }, 4000);
    }
});