'use strict';

window.addEventListener('DOMContentLoaded', () => {

    /*...Header menu mobile...*/
    const mobileOpen = document.querySelector("[data-mobileOpen]"),
    menuMobile = document.querySelectorAll("[data-menuMobile]"),
    mobileClose = document.querySelector("[data-mobileClose]");


    function hideMobileMenu() {
    menuMobile.forEach(item => {
    item.classList.add("menu__hide");
    });
    mobileClose.classList.add("menu__hide");
    }

    hideMobileMenu();

    mobileOpen.addEventListener("click", function (evt) { 
    evt.preventDefault();
    mobileOpen.classList.add("menu__hide"); 
    mobileClose.classList.remove("menu__hide");

    menuMobile.forEach(item => {
    item.classList.remove("menu__hide");
    });
    });

    mobileClose.addEventListener("click", function (evt) { 
    evt.preventDefault();
    hideMobileMenu();
    mobileOpen.classList.remove("menu__hide");
    });
});
