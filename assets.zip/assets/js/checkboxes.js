'use strict';

window.addEventListener('DOMContentLoaded', () => {

  /*...Checkboxes..*/

  const radioItem = document.querySelectorAll('[data-radioCheck]'),
  checkbox = document.querySelectorAll('[data-checkbox]');


  radioItem[0].addEventListener("click", function (evt) { 
  evt.preventDefault();

  switch(radioItem[0].getAttribute('aria-checked')) {
  case "true":
  radioItem[0].setAttribute('aria-checked', "false");
  radioItem[1].setAttribute('aria-checked', "true");
    break;
  case "false":
  radioItem[0].setAttribute('aria-checked', "true");
  radioItem[1].setAttribute('aria-checked', "false");
    break;
  }
  });

  radioItem[1].addEventListener("click", function (evt) { 
  evt.preventDefault();

  switch(radioItem[1].getAttribute('aria-checked')) {
  case "true":
  radioItem[1].setAttribute('aria-checked', "false");
  radioItem[0].setAttribute('aria-checked', "true");
    break;
  case "false":
  radioItem[1].setAttribute('aria-checked', "true");
  radioItem[0].setAttribute('aria-checked', "false");
    break;
  }
  });

  checkbox.forEach(item => {
  item.addEventListener("click", function (evt) { 
  evt.preventDefault();
  item.getAttribute('aria-checked');
  switch(item.getAttribute('aria-checked')) {
    case "true":
      item.setAttribute('aria-checked', "false");
        break;
    case "false":
      item.setAttribute('aria-checked', "true");
        break;
  }
  });
  });
});