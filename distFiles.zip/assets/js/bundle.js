/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/assets/js/modules/checkCheckbox.js":
/*!************************************************!*\
  !*** ./src/assets/js/modules/checkCheckbox.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function checkCheckbox(checkboxes) {
    const checkbox = document.querySelectorAll(checkboxes);

    checkbox.forEach(item => {
        item.addEventListener("click", function (evt) { 
          evt.preventDefault();
          item.getAttribute('aria-checked');
          switch(item.getAttribute('aria-checked')) {
            case "true":
              item.setAttribute('aria-checked', "false");
                break;
            case "false":
              item.setAttribute('aria-checked', "true");
                break;
          }
        });
    }); 

}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (checkCheckbox);

/***/ }),

/***/ "./src/assets/js/modules/checkRadiobox.js":
/*!************************************************!*\
  !*** ./src/assets/js/modules/checkRadiobox.js ***!
  \************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function checkRadiobox(RadioPoints) {
    const radioItem = document.querySelectorAll(RadioPoints);
    

    radioItem[0].addEventListener("click", function (evt) { 
        evt.preventDefault();

        switch(radioItem[0].getAttribute('aria-checked')) {
        case "true":
        radioItem[0].setAttribute('aria-checked', "false");
        radioItem[1].setAttribute('aria-checked', "true");
            break;
        case "false":
        radioItem[0].setAttribute('aria-checked', "true");
        radioItem[1].setAttribute('aria-checked', "false");
            break;
        }
    });

    radioItem[1].addEventListener("click", function (evt) { 
        evt.preventDefault();

        switch(radioItem[1].getAttribute('aria-checked')) {
        case "true":
        radioItem[1].setAttribute('aria-checked', "false");
        radioItem[0].setAttribute('aria-checked', "true");
            break;
        case "false":
        radioItem[1].setAttribute('aria-checked', "true");
        radioItem[0].setAttribute('aria-checked', "false");
            break;
        }
    }); 
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (checkRadiobox);

/***/ }),

/***/ "./src/assets/js/modules/headerMenuMobile.js":
/*!***************************************************!*\
  !*** ./src/assets/js/modules/headerMenuMobile.js ***!
  \***************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
function headerMenuMobile(openedMenu, openButton, closeButton) {
  
  const mobileOpen = document.querySelector(openButton),
         menuMobile = document.querySelectorAll(openedMenu),
         mobileClose = document.querySelector(closeButton);
 
 
   function hideMobileMenu() {
     menuMobile.forEach(item => {
       item.classList.add("menu__hide");
     });
     mobileClose.classList.add("menu__hide");
   }
 
   hideMobileMenu();
 
   mobileOpen.addEventListener("click", function (evt) { 
     evt.preventDefault();
     mobileOpen.classList.add("menu__hide"); 
     mobileClose.classList.remove("menu__hide");

     menuMobile.forEach(item => {
       item.classList.remove("menu__hide");
     });
   });
 
   mobileClose.addEventListener("click", function (evt) { 
     evt.preventDefault();
     hideMobileMenu();
     mobileOpen.classList.remove("menu__hide");
   });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (headerMenuMobile);

/***/ }),

/***/ "./src/assets/js/modules/modal.js":
/*!****************************************!*\
  !*** ./src/assets/js/modules/modal.js ***!
  \****************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__),
/* harmony export */   "closeModal": () => (/* binding */ closeModal),
/* harmony export */   "openModal": () => (/* binding */ openModal)
/* harmony export */ });
function openModal(item, openClass) {
  item.classList.add(openClass);
  document.body.style.overflow = 'hidden';
}

function closeModal(item, openClass) {
  item.classList.remove(openClass);
  document.body.style.overflow = '';
}

function modal(modalWindow, openModalButton, closeModalButton, autofocusElement,postForm, ) {
    /*...modal windows...*/
    const modal = document.querySelector(modalWindow),
          openButton = document.querySelectorAll(openModalButton),
          closeButton = document.querySelector(closeModalButton),
          autofocus = document.querySelector(autofocusElement);

    openButton.forEach(btn => {
      btn.addEventListener("click", () => { 
        openModal(modal, 'modal-show');
        autofocus.focus();
      });
    });

    closeButton.addEventListener("click", (e) => { 
      if(e.target === closeButton) {
        closeModal(modal, 'modal-show'); 
      }
    });

    document.addEventListener('keydown', (e) => {
      if(e.code === "Escape" && modal.classList.contains('modal-show')) {
          closeModal(modal, 'modal-show'); 
      }
    });
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (modal);


/***/ }),

/***/ "./src/assets/js/modules/postModalWindow.js":
/*!**************************************************!*\
  !*** ./src/assets/js/modules/postModalWindow.js ***!
  \**************************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _services_services__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../services/services */ "./src/assets/js/services/services.js");
/* harmony import */ var _modal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modal */ "./src/assets/js/modules/modal.js");



function postModalWindow(modalWindow, postForm, changeModalPartClass) {
    const modal = document.querySelector(modalWindow),
          form = modal.querySelector(postForm),
          message = {
            loading: 'assets/img/forms/spinner.svg',
            success: 'Спасибо, скоро мы с вами свяжемся',
            failure: 'Что-то пошло не так...'
          };

    bindPostData(form); 

    function bindPostData(formItem) {
      formItem.addEventListener('submit', (e) => {
          e.preventDefault();

          const statusMessage = document.createElement('img');
          statusMessage.src = message.loading;
          statusMessage.style.cssText = `
              display: block;
              margin: 0 auto;
          `;

          formItem.insertAdjacentElement('afterend', statusMessage);

          const formData = new FormData(form);

          const json = JSON.stringify(Object.fromEntries(formData.entries()));

          (0,_services_services__WEBPACK_IMPORTED_MODULE_0__.postData)('http://localhost:3000/requests', json)
          .then(data => {
              console.log(data);
              showThanksModal(message.success);
              statusMessage.remove(); 
          }).catch(() => {
              showThanksModal(message.failure);
          }).finally(() => {
              form.reset(); 
          });

      });
    }  

    function showThanksModal(message) {
      const prevModalDialog = modal.querySelector('.modal');
      console.log(prevModalDialog);

      prevModalDialog.classList.add('hide');
      (0,_modal__WEBPACK_IMPORTED_MODULE_1__.openModal)(modal, 'modal-show');

      const thanksModal = document.createElement('div');
      thanksModal.style.padding = "50px";
      thanksModal.classList.add('modal');
      thanksModal.innerHTML = `
          <div>
              <p class="modal__title">${message}</p> 
          </div>
      `;

      modal.append(thanksModal);

      console.log(thanksModal);

      setTimeout(() => {
          thanksModal.remove();
          prevModalDialog.classList.add('show');
          prevModalDialog.classList.remove('hide');
          (0,_modal__WEBPACK_IMPORTED_MODULE_1__.closeModal)(modal, 'modal-show');
      }, 4000);
    }
}

/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (postModalWindow);

/***/ }),

/***/ "./src/assets/js/services/services.js":
/*!********************************************!*\
  !*** ./src/assets/js/services/services.js ***!
  \********************************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "postData": () => (/* binding */ postData)
/* harmony export */ });
const postData = async (url, data) => {
    let res = await fetch(url, {
        method: "POST",
        headers: {
            'Content-Type': 'application/json'
        },
        body: data
    });

    return await res.json();
};




/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId](module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	/* webpack/runtime/define property getters */
/******/ 	(() => {
/******/ 		// define getter functions for harmony exports
/******/ 		__webpack_require__.d = (exports, definition) => {
/******/ 			for(var key in definition) {
/******/ 				if(__webpack_require__.o(definition, key) && !__webpack_require__.o(exports, key)) {
/******/ 					Object.defineProperty(exports, key, { enumerable: true, get: definition[key] });
/******/ 				}
/******/ 			}
/******/ 		};
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/hasOwnProperty shorthand */
/******/ 	(() => {
/******/ 		__webpack_require__.o = (obj, prop) => (Object.prototype.hasOwnProperty.call(obj, prop))
/******/ 	})();
/******/ 	
/******/ 	/* webpack/runtime/make namespace object */
/******/ 	(() => {
/******/ 		// define __esModule on exports
/******/ 		__webpack_require__.r = (exports) => {
/******/ 			if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 				Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 			}
/******/ 			Object.defineProperty(exports, '__esModule', { value: true });
/******/ 		};
/******/ 	})();
/******/ 	
/************************************************************************/
var __webpack_exports__ = {};
// This entry need to be wrapped in an IIFE because it need to be isolated against other modules in the chunk.
(() => {
/*!******************************!*\
  !*** ./src/assets/js/app.js ***!
  \******************************/
__webpack_require__.r(__webpack_exports__);
/* harmony import */ var _modules_headerMenuMobile__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./modules/headerMenuMobile */ "./src/assets/js/modules/headerMenuMobile.js");
/* harmony import */ var _modules_modal__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ./modules/modal */ "./src/assets/js/modules/modal.js");
/* harmony import */ var _modules_checkCheckbox__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./modules/checkCheckbox */ "./src/assets/js/modules/checkCheckbox.js");
/* harmony import */ var _modules_checkRadiobox__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ./modules/checkRadiobox */ "./src/assets/js/modules/checkRadiobox.js");
/* harmony import */ var _modules_postModalWindow__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(/*! ./modules/postModalWindow */ "./src/assets/js/modules/postModalWindow.js");








window.addEventListener('DOMContentLoaded', () => {
  (0,_modules_headerMenuMobile__WEBPACK_IMPORTED_MODULE_0__.default)("[data-menuMobile]", "[data-mobileOpen]", "[data-mobileClose]");

  // order modal
  try {
    (0,_modules_modal__WEBPACK_IMPORTED_MODULE_1__.default)("[data-orderModal]", "[data-modalOpen]", "[data-orderClose]", ".size-s");
  } catch(e) {
    console.log(e);
  }

  //review modal

  try {
    (0,_modules_modal__WEBPACK_IMPORTED_MODULE_1__.default)("[data-reviewModal]", "[data-reviewOpen]", "[data-reviewClose]","#firstname");
    (0,_modules_postModalWindow__WEBPACK_IMPORTED_MODULE_4__.default)("[data-reviewModal]", 'form', '.modal');
  } catch(e) {
    console.log(e);
  }

  try {
    (0,_modules_checkRadiobox__WEBPACK_IMPORTED_MODULE_3__.default)('[data-radioCheck]');
  } catch(e) {
    console.log(e);
  }

  try {
    (0,_modules_checkCheckbox__WEBPACK_IMPORTED_MODULE_2__.default)('[data-checkbox]');
  } catch(e) {
    console.log(e);
  }

});




})();

/******/ })()
;
//# sourceMappingURL=bundle.js.map