'use strict';

import headerMenuMobile from './modules/headerMenuMobile';
import modal from './modules/modal';
import checkCheckbox from './modules/checkCheckbox';
import checkRadiobox from './modules/checkRadiobox';
import postModalWindow from './modules/postModalWindow';

window.addEventListener('DOMContentLoaded', () => {
  headerMenuMobile("[data-menuMobile]", "[data-mobileOpen]", "[data-mobileClose]");

  // order modal
  try {
    modal("[data-orderModal]", "[data-modalOpen]", "[data-orderClose]", ".size-s");
  } catch(e) {
    console.log(e);
  }

  //review modal

  try {
    modal("[data-reviewModal]", "[data-reviewOpen]", "[data-reviewClose]","#firstname");
    postModalWindow("[data-reviewModal]", 'form');
  } catch(e) {
    console.log(e);
  }

  try {
    checkRadiobox('[data-radioCheck]');
  } catch(e) {
    console.log(e);
  }

  try {
    checkCheckbox('[data-checkbox]');
  } catch(e) {
    console.log(e);
  }

});



