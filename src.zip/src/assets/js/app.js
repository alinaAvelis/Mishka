'use strict';

import headerMenuMobile from './modules/headerMenuMobile';
import modal from './modules/modal';
import checkCheckbox from './modules/checkCheckbox';
import checkRadiobox from './modules/checkRadiobox';
import postModalWindow from './modules/postModalWindow';
import postForm from './modules/postForm';

window.addEventListener('DOMContentLoaded', () => {
  headerMenuMobile("[data-menuMobile]", "[data-mobileOpen]", "[data-mobileClose]");

  const message = {
    loading: 'assets/img/forms/spinner.svg',
    success: 'Спасибо, скоро мы с вами свяжемся!',
    successforReview: 'Спасибо за ваш отзыв!',
    failure: 'Что-то пошло не так...'
  };

  // order modal
  try {
    modal("[data-orderModal]", "[data-modalOpen]", "[data-modalClose]", ".size-s");
  } catch(e) {
    console.log(e);
  }

  //review modal

  try {
    modal("[data-reviewModal]", "[data-reviewOpen]", "[data-modalClose]","#firstname");
    postModalWindow("[data-reviewModal]", 'form', 'http://localhost:3000/reviews', message.loading, message.successforReview, message.failure);
  } catch(e) {
    console.log(e);
  }

  //callUs modal

  try {
    modal("[data-callUsModal]", "[data-callUsOpen]", "[data-modalClose]",".firstname");
    postModalWindow("[data-callUsModal]", 'form', 'http://localhost:3000/requests',message.loading, message.success, message.failure);
  } catch(e) {
    console.log(e);
  }

  //checkbox and radioBtn

  try {
    checkRadiobox('[data-radioCheck]');
  } catch(e) {
    console.log(e);
  }

  try {
    checkCheckbox('[data-checkbox]');
  } catch(e) {
    console.log(e);
  }

  //order form

  try {
    postForm('form', 'http://localhost:3000/orders', message.loading, message.success, message.failure);
  } catch(e) {
    console.log(e);
  }

});



