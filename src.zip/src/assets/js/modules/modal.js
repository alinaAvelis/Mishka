function openModal(item, openClass) {
  item.classList.add(openClass);
  document.body.style.overflow = 'hidden';
}

function closeModal(item, openClass) {
  item.classList.remove(openClass);
  document.body.style.overflow = '';
}

function modal(modalWindow, openModalButton, closeModalButton, autofocusElement,postForm, ) {
    /*...modal windows...*/
    const modal = document.querySelector(modalWindow),
          openButton = document.querySelectorAll(openModalButton),
          closeButton = document.querySelector(closeModalButton),
          autofocus = document.querySelector(autofocusElement);

    openButton.forEach(btn => {
      btn.addEventListener("click", () => { 
        openModal(modal, 'modal-show');
        autofocus.focus();
      });
    });

    closeButton.addEventListener("click", (e) => { 
      if(e.target === closeButton) {
        closeModal(modal, 'modal-show'); 
      }
    });

    document.addEventListener('keydown', (e) => {
      if(e.code === "Escape" && modal.classList.contains('modal-show')) {
          closeModal(modal, 'modal-show'); 
      }
    });
}

export default modal;
export {closeModal, openModal};