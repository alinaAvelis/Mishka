import {postData} from '../services/services';
import {closeModal, openModal} from './modal';

function postModalWindow(modalWindow, postForm, postUrl, urlForLodindImg, successMessage, failureMessage) {
    const modal = document.querySelector(modalWindow),
          form = modal.querySelector(postForm);

    bindPostData(form, postUrl, urlForLodindImg, successMessage, failureMessage); 

    function bindPostData(formItem, urlforPost, imgUrl, successText, failureText) {
      formItem.addEventListener('submit', (e) => {
          e.preventDefault();

          const statusMessage = document.createElement('img');
          statusMessage.src = imgUrl;
          statusMessage.style.cssText = `
              display: block;
              margin: 0 auto;
          `;

          formItem.insertAdjacentElement('afterend', statusMessage);

          const formData = new FormData(form);

          const json = JSON.stringify(Object.fromEntries(formData.entries()));

          postData(urlforPost, json)
          .then(data => {
              console.log(data);
              showThanksModal(successText);
              statusMessage.remove(); 
          }).catch(() => {
              showThanksModal(failureText);
          }).finally(() => {
              form.reset(); 
          });

      });
    }  

    function showThanksModal(message) {
      const prevModalDialog = modal.querySelector('.modal');

      prevModalDialog.classList.add('hide');
      openModal(modal, 'modal-show');

      const thanksModal = document.createElement('div');
      thanksModal.style.padding = "50px";
      thanksModal.classList.add('modal');
      thanksModal.innerHTML = `
          <div>
              <p class="modal__title">${message}</p> 
          </div>
      `;

      modal.append(thanksModal);

      setTimeout(() => {
          thanksModal.remove();
          prevModalDialog.classList.add('show');
          prevModalDialog.classList.remove('hide');
          closeModal(modal, 'modal-show');
      }, 4000);
    }
}

export default postModalWindow;