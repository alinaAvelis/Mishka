import {postData} from '../services/services';
import {closeModal, openModal} from './modal';

function postModalWindow(modalWindow, postForm) {
    const modal = document.querySelector(modalWindow),
          form = modal.querySelector(postForm),
          message = {
            loading: 'assets/img/forms/spinner.svg',
            success: 'Спасибо, скоро мы с вами свяжемся!',
            failure: 'Что-то пошло не так...'
          };

    bindPostData(form); 

    function bindPostData(formItem) {
      formItem.addEventListener('submit', (e) => {
          e.preventDefault();

          const statusMessage = document.createElement('img');
          statusMessage.src = message.loading;
          statusMessage.style.cssText = `
              display: block;
              margin: 0 auto;
          `;

          formItem.insertAdjacentElement('afterend', statusMessage);

          const formData = new FormData(form);

          const json = JSON.stringify(Object.fromEntries(formData.entries()));

          postData('http://localhost:3000/requests', json)
          .then(data => {
              console.log(data);
              showThanksModal(message.success);
              statusMessage.remove(); 
          }).catch(() => {
              showThanksModal(message.failure);
          }).finally(() => {
              form.reset(); 
          });

      });
    }  

    function showThanksModal(message) {
      const prevModalDialog = modal.querySelector('.modal');

      prevModalDialog.classList.add('hide');
      openModal(modal, 'modal-show');

      const thanksModal = document.createElement('div');
      thanksModal.style.padding = "50px";
      thanksModal.classList.add('modal');
      thanksModal.innerHTML = `
          <div>
              <p class="modal__title">${message}</p> 
          </div>
      `;

      modal.append(thanksModal);

      setTimeout(() => {
          thanksModal.remove();
          prevModalDialog.classList.add('show');
          prevModalDialog.classList.remove('hide');
          closeModal(modal, 'modal-show');
      }, 4000);
    }
}

export default postModalWindow;