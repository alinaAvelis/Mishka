function checkRadiobox(RadioPoints) {
    const radioItem = document.querySelectorAll(RadioPoints);
    

    radioItem[0].addEventListener("click", function (evt) { 
        evt.preventDefault();

        switch(radioItem[0].getAttribute('aria-checked')) {
        case "true":
        radioItem[0].setAttribute('aria-checked', "false");
        radioItem[1].setAttribute('aria-checked', "true");
            break;
        case "false":
        radioItem[0].setAttribute('aria-checked', "true");
        radioItem[1].setAttribute('aria-checked', "false");
            break;
        }
    });

    radioItem[1].addEventListener("click", function (evt) { 
        evt.preventDefault();

        switch(radioItem[1].getAttribute('aria-checked')) {
        case "true":
        radioItem[1].setAttribute('aria-checked', "false");
        radioItem[0].setAttribute('aria-checked', "true");
            break;
        case "false":
        radioItem[1].setAttribute('aria-checked', "true");
        radioItem[0].setAttribute('aria-checked', "false");
            break;
        }
    }); 
}

export default checkRadiobox;