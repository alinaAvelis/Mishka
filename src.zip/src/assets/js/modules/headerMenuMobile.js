function headerMenuMobile(openedMenu, openButton, closeButton) {
  
  const mobileOpen = document.querySelector(openButton),
         menuMobile = document.querySelectorAll(openedMenu),
         mobileClose = document.querySelector(closeButton);
 
 
   function hideMobileMenu() {
     menuMobile.forEach(item => {
       item.classList.add("menu__hide");
     });
     mobileClose.classList.add("menu__hide");
   }
 
   hideMobileMenu();
 
   mobileOpen.addEventListener("click", function (evt) { 
     evt.preventDefault();
     mobileOpen.classList.add("menu__hide"); 
     mobileClose.classList.remove("menu__hide");

     menuMobile.forEach(item => {
       item.classList.remove("menu__hide");
     });
   });
 
   mobileClose.addEventListener("click", function (evt) { 
     evt.preventDefault();
     hideMobileMenu();
     mobileOpen.classList.remove("menu__hide");
   });
}

export default headerMenuMobile;