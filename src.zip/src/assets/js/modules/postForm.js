import {postData} from '../services/services';

function postForm(formSelector, urlforPost, imgUrl, successText, failureText) {
    const forms = document.querySelectorAll(formSelector);

    forms.forEach(item => {
        item.addEventListener('submit', (e) => {
            e.preventDefault();
  
            postForm();
  
            const statusMessage = document.createElement('img');
            statusMessage.src = imgUrl;
            statusMessage.style.cssText = `
                display: block;
                margin: 0 auto;
            `;
  
            item.insertAdjacentElement('afterend', statusMessage);
  
            const formData = new FormData(item);
  
            const json = JSON.stringify(Object.fromEntries(formData.entries()));
  
            postData(urlforPost, json)
            .then(data => {
                console.log(data);
                showThanksModal(successText);
                statusMessage.remove(); 
            }).catch(() => {
                showThanksModal(failureText);
            }).finally(() => {
                item.reset(); 
            });
  
        }); 
    });

    function showThanksModal(message) {  
        const thanksModal = document.createElement('div');
        thanksModal.classList.add("modal-window");
        thanksModal.innerHTML = `
            <div class="modal-background" data-modalClose>
                <div class="modal">
                    <p class="modal__title">${message}</p>
                </div>
            </div>
        `;
        thanksModal.classList.add('modal-show');
  
        document.body.append(thanksModal);
  
        setTimeout(() => {
            thanksModal.classList.remove('modal-show');
            thanksModal.remove();
        }, 4000);
      }
}

export default postForm;